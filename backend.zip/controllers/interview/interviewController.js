let app = require('express');
let router = app.Router();
let interview = require('../../models').interview;
let interview_fixed_questions = require('../../models').interview_fixed_questions;
let user_groups_map = require('../../models').user_groups_map;
let users = require('../../models').users;
let interview_users = require('../../models').interview_users;
let interview_user_questions = require('../../models').interview_user_questions;
let sequelize = require('../../models').sequelize;
let questions = require('../../models').questions;
const Op = sequelize.Op;
var randomize = require('randomatic');
let mails = require('../email');
const async = require('async');

router.post('/create',(req,res)=>{
      console.log(req.auth);
	if(req.auth.access.addAccess && req.auth.organization){
            let userData = req.body;
            console.log(userData);
            interview.findAndCountAll({where:{organizationId:req.auth.organization}}).then(intData=>{
                  let intDataCount = (Number(intData.count)+1).toString();
                  let org_id = ((req.auth.organization).toString()).padStart(2, "0");
                  let DomnId = ((userData.domainId).toString()).padStart(3, "0")
                  let interviewId = "AI"+org_id+DomnId+"-"+intDataCount.padStart(6, "0");
                  sequelize.transaction(t=>{
                        interview.afterCreate(function(model, options, done) {//hook1
                              model.auth = req.auth ? req.auth.userId : 0;
                        });
                        return interview.create({type:"async",domainId:userData.domainId,interviewId:interviewId,subDomainId:userData.subDomainId,expLevelId:userData.expLevelId,start_date:userData.start_date,end_date:userData.end_date,duration:userData.duration,questionCount:userData.questionCount,organizationId:req.auth.organization,userId:req.auth.userId},{transaction:t}).then(dataSaved=>{
                              interview_fixed_questions.afterBulkCreate(function(model,options) {
						options.auth = req.auth ? req.auth.userId : 0;
					});
                              return interview_fixed_questions.bulkCreate(userData.questons.map((v,i)=>{
                                    return {interviewId:dataSaved.id, questionId:v.id};
                              }),{transaction:t});
                        })
                  }).then(finalResult=>{
                        res.send({status:true,message:"success"});
                  }).catch(err=>{
                        console.log(err);
                        res.send({status:false,message:"fail"});
                  });
            }).catch(err=>{
                  console.log(err)
                  res.send({status:false,message:"fail"});
            });
      }else{
            res.send({status:false,message:"un-Authorized."})
      }
});

router.get('/view',(req,res)=>{
	if(req.auth.access.gridAccess && req.auth.organization){
            interview.findAll({where:{organizationId:req.auth.organization}}).then(data=>{
                  res.send({status:true,access:req.auth.access,data:data});
            }).catch(err=>{
                  res.send({status:false,access:req.auth.access,message:"fail."});
            });
      }else{
            res.send({status:false,message:"un-Authorized.",access:req.auth.access})
      }
});

router.get('/interview-list',(req,res)=>{
      if(req.auth.organization){
            interview.findAll({attributes:['id','interviewId'],where:{organizationId:req.auth.organization}}).then(data=>{
                  res.send({status:true,access:req.auth.access,data:data});
            }).catch(err=>{
                  res.send({status:false,access:req.auth.access,message:"fail."});
            });
      }else{
            res.send({status:false,message:"un-Authorized.",access:req.auth.access})
      }
})

router.post('/map-groups',(req,res)=>{
      let userData = req.body;
      //============ get all emails from user groups =================
      if(!userData.usergroups){
            userData.usergroups = [{id:0}];
      }
            //let qry = "SELECT DISTINCT users.email FROM user_groups_map left join users on user_groups_map.userId = users.id where user_groups_map.groupId in ("+userData.usergroups+")";
            users.findAll({attributes:["email"],include:[{ model: user_groups_map,where: { groupId:  {[Op.in]: userData.usergroups.map((v,i)=>{return [v.id];})}}}]}).then(data=>{
                  let emails = data.map((v,i)=>{
                        return v.email;
                  });
                  
                  //========== combine two arrays =================
                  emails = emails.concat(userData.emails.split(","));
                  //============ remove duplicate data ==============
                  emails = emails.filter((v, i, a) => a.indexOf(v) === i);
                  interview_users.findAll({where:{interviewId:userData.interviewid}}).then(mailDataAlrdExist=>{
                        let new_emails = mailDataAlrdExist.map((v6,i6)=>{return v6.email});
                        //=========== remove common data which contains in array 2 ===========
                        let uniqueMails = emails.filter(val => !new_emails.includes(val));
                        let datToSave = uniqueMails.map((v1,i1)=>{return {interviewId:userData.interviewid,email:v1,status:'Available',link:'none',pin:(randomize('0', 5).toString()).padStart(5,"0")};});
                        if(datToSave.length>0){
                              interview.findOne({include:[{model : interview_fixed_questions}],where:{id:userData.interviewid}}).then(fixedQuestionsList=>{
                                    let fixedQuesIds = fixedQuestionsList.interview_fixed_questions.map((itm,ind)=>{
                                          return itm.questionId;
                                    });
                                    questions.findAll({where:{domainId:fixedQuestionsList.domainId,subDomainId:fixedQuestionsList.subDomainId,expLevelId:fixedQuestionsList.expLevelId,[Op.or]: [{organizationId: fixedQuestionsList.organizationId}, {organizationId: null}]}}).then(allques=>{
                                          let allQuestionsList = {};
                                          allques.forEach(eleem=>{
                                                allQuestionsList['ques'+eleem.id] = eleem.question;
                                          })
                                          let TobeGenRandomQuesCnt = fixedQuestionsList.questionCount - fixedQuesIds.length;
                                          let LowQuestions = ((allques.map((v,i)=>{return v.difficulty=='low' ? v.id : null;})).filter(function (el) {return el != null;})).filter(val => !fixedQuesIds.includes(val));
                                          let MediumQuestions = ((allques.map((v,i)=>{return v.difficulty=='medium' ? v.id : null;})).filter(function (el) {return el != null;})).filter(val => !fixedQuesIds.includes(val));
                                          let HighQuestions = ((allques.map((v,i)=>{return v.difficulty=='high' ? v.id : null;})).filter(function (el) {return el != null;})).filter(val => !fixedQuesIds.includes(val));
                                          let LowQuestionsCount = TobeGenRandomQuesCnt>0 ? Math.floor(TobeGenRandomQuesCnt/3) : 0;
                                          let MediumQuestionsCount = TobeGenRandomQuesCnt>0 ? Math.round(TobeGenRandomQuesCnt/3) : 0;
                                          let HighQuestionsCount = TobeGenRandomQuesCnt - (LowQuestionsCount+MediumQuestionsCount);
                                          if(LowQuestionsCount<=LowQuestions.length && MediumQuestionsCount<=MediumQuestions.length && HighQuestionsCount<=HighQuestions.length){
                                                sequelize.transaction(t=>{
                                                      interview_users.afterBulkCreate(function(model,options) {
                                                            options.auth = req.auth ? req.auth.userId : 0;
                                                      });
                                                      return interview_users.bulkCreate(datToSave, {transaction: t}).then(savedData=>{
                                                            var promises = [];
                                                            savedData.forEach(element => {
                                                                  let fixedQuesIds1 = fixedQuesIds.map((a,b)=>{
                                                                        return {type:"fixed",interviewUserId:element.id,questionId:a,maxCount:fixedQuestionsList.questionCount,questionTitle:allQuestionsList['ques'+a],ano:b+1,qTime:fixedQuestionsList.duration}
                                                                  });
                                                                  let questionsetRandom = [];
                                                                  questionsetRandom = questionsetRandom.concat((LowQuestions.sort(function() {return .5 - Math.random();})).splice(0,LowQuestionsCount));
                                                                  questionsetRandom = questionsetRandom.concat((MediumQuestions.sort(function() {return .5 - Math.random();})).splice(0,MediumQuestionsCount));
                                                                  questionsetRandom = questionsetRandom.concat((HighQuestions.sort(function() {return .5 - Math.random();})).splice(0,HighQuestionsCount));
                                                                  let newInsQSet = questionsetRandom.map((a,b)=>{return {type:"random",interviewUserId:element.id,questionId:a,maxCount:fixedQuestionsList.questionCount,questionTitle:allQuestionsList['ques'+a],ano:fixedQuesIds1.length+b+1,qTime:fixedQuestionsList.duration}});
                                                                  newInsQSet = fixedQuesIds1.concat(newInsQSet);
                                                                  let newPromise = interview_user_questions.bulkCreate(newInsQSet,{transaction:t});
                                                                  promises.push(newPromise);
                                                            });
                                                            return Promise.all(promises); 
                                                      });
                                                }).then(finalData=>{
                                                      let sendMailPass = datToSave.map((v,i)=>{return {'email':v.email,'content':"Interview Id is: <b style='color:red'>"+fixedQuestionsList.interviewId+"</b><br/>Pin is: <b style='color:red'>"+v.pin+"</b>"};});
                                                      async.parallel([
                                                            function (callback) {
                                                                mails.sendEmail(
                                                                callback,
                                                                'iamchandu.20@gmail.com',
                                                                sendMailPass,
                                                                'Interview Scheduled on '+fixedQuestionsList.start_date
                                                            );
                                                            }
                                                        ], function(err, results) {
                                                            res.send({'status':true,'message':'Success'});
                                                        });
                                                }).catch(err=>{
                                                      console.log(err);
                                                      res.send({status:false,message:"fail"});
                                                });
                                          }else{
                                                res.send({status:false,message:"insufficient Questions. Please upload Question Sets for the interview."})
                                          }

                                    });
                              });
                        }else{
                              res.send({status:false,message:"Data Already Sent."});
                        }
                  });
            }).catch(err=>{
                  console.log(err);
                  res.send({status:false,message:"fail."});
            });
      
});

router.get('/view/:id',(req,res)=>{
      interview.findOne({where:{id:req.params.id}}).then(data=>{
            res.send({status:true,data:data});
      });
});

router.get('/asynctest/:interviewId',(req,res)=>{
      if(req.auth.email){
            interview_users.findOne({where:{email:req.auth.email,interviewId:req.params.interviewId}}).then(examData=>{
                  if(examData){
                        interview_user_questions.findOne({attributes:['id', 'type', 'interviewUserId', 'questionId', 'ano', 'qTime', 'status', ['maxCount','max_count'], ['timeTaken','time_taken'],["questionTitle","q_title"]],where:{status:0,interviewUserId:examData.id},order: [['ano', 'ASC']]}).then(exam=>{
                              if (exam) {
                                    exam.q_title = exam.questionTitle;
                                    res.send (exam);
                              } else {
                                    res.send ({message: 'no data found!'});
                              }
                        }).catch(err=>{
                              res.send ({message: 'no data found!'});
                        })
                  }else{
                        res.send ({message: 'no data found!'});
                  }
            }).catch(err=>{
                  res.send ('unable to access');
            })
      }else{
            res.send ('unable to access');
      }
})

router.post('/asynctest/update',(req,res)=>{
      interview_user_questions.afterBulkUpdate(function(options) {//hook1
            options.auth = req.auth ? req.auth.userId : 0;
      });
      console.log(req.body);
      interview_user_questions.update ({uid: req.body.uid, answerText: req.body.answer, answerLink: req.body.videoURL, status: req.body.status, timeTaken: req.body.time_taken },{where: {id: req.body.id}}).then (resp => res.send (resp)).catch (err => res.send ('unable to update'));
});

router.get('/videos/:interviewid',(req,res)=>{
      if(req.auth.email){
            interview_users.findOne({include:[{model:interview_user_questions,attributes:["id","uid",["questionTitle","q_title"],["answerLink","videoURL"],["timeTaken","time_taken"]]}],where:{id:req.params.interviewid,email:req.auth.email}}).then(data=>{
                  //console.log(data);
                  if(data.interview_user_questions)
                        res.send(data.interview_user_questions)
                  else
                        res.send ({message: 'no data found!'});
            }).catch(err=>{
                  console.log(err);
                  res.send ('unable to access')
            })
      }else{

      }
})

router.get('/getinterviews',(req,res)=>{
      if(req.auth.email){
            sequelize.query("SELECT interview_users.id,interview_users.email,interview_users.pin,interview_users.link,interview.interviewId as InterviewId,paymentstatus,domain.domainName,domain.id as domain,sub_domains.subDomainName,sub_domains.id as subdomain,interview_users.status FROM `interview_users` left join interview on interview_users.interviewId = interview.id left join domain on interview.domainId = domain.id left join sub_domains on interview.subDomainId = sub_domains.id where interview_users.email='"+req.auth.email+"'", { type: sequelize.QueryTypes.SELECT})
            .then(data => {
                  if(data)
                        res.send(data);
                  else
                        res.send ({message: 'no data found!'});
            }).catch(err=>{
                  res.send ('unable to access')
            })
      }else{
            res.send ('unable to access')
      }
});

router.get('/verifypin/:pin',(req,res)=>{
      interview_users.findOne({where:{pin:req.params.pin,email:req.auth.email}}).then(data=>{
            if(data){
                  res.send(data);
            }else
                  res.send ({message: 'no data found!'});
      }).catch(err=>{
            res.send ('unable to access');
      })
});

router.post('/updatepin',(req,res)=>{
      interview_users.afterBulkUpdate(function(options) {//hook1
            options.auth = req.auth ? req.auth.userId : 0;
      });

      interview_users.update({status:req.body.status},{where:{pin:req.body.pin,email:req.auth.email}}).then (resp => res.send (resp)).catch (err => res.send ('unable to update'));
});

router.get('/getCompletedInterviews',(req,res)=>{
      sequelize.query("SELECT interview_users.id,interview_users.email,interview_users.pin,interview_users.link,interview.interviewId,domain.domainName,sub_domains.subDomainName,interview_users.status FROM `interview_users` left join interview on interview_users.interviewId = interview.id left join domain on interview.domainId = domain.id left join sub_domains on interview.subDomainId = sub_domains.id where interview_users.email='"+req.auth.email+"' and interview_users.status in ('Completed','Reviewed','expertreview')", { type: sequelize.QueryTypes.SELECT})
      .then(data => {
            if(data)
                  res.send(data);
            else
                  res.send ({message: 'no data found!'});
      }).catch(err=>{
            res.send ('unable to access')
      })
});

module.exports = router;