let app = require('express');
let router = app.Router();
let report_perameters = require('../models').report_perameters;
let sequelize = require('../models').sequelize;
const Op = sequelize.Op;


router.get('/',(req,res)=>{
    if(req.auth.access.gridAccess && req.auth.organization){
        report_perameters.findAll({ where : {organizationId:req.auth.organization}}).then(experiance => {
          if(experiance){
              res.send({'status' : true, "data" : experiance, access:req.auth.access});
          }else{
              res.send({'status' : false, 'message':'fail'});
          }
      }).catch(function (error) {
          res.status(500).send('Internal Server Error');
          });
    }else{
          res.send({'status' : false, 'message':'Un Authroized', access:[req.auth.access]});
    }
          
});

router.post('/',(req,res)=>{
    if(req.auth.access.addAccess && req.auth.organization){
        report_perameters.findOne({ where : {organizationId:req.auth.organization,name:req.body.name}}).then(experiance => {
          if(experiance){
              res.send({'status' : false, "message":"Data Already Exist."});
          }else{
              //============= insert query =====================
              report_perameters.afterCreate(function(model, options, done) {//hook1
                  model.auth = req.auth ? req.auth.userId : 0;
              });
              report_perameters.create({name:req.body.name,organizationId:req.auth.organization,userId:req.auth.userId,status:'active'}).then(result=>{
                  res.send({'status' : true, 'message':'Success'});
              }).catch(err=>{
                  res.send({"status":false,"message":"fail111"});
              });
          }
      }).catch(function (error) {
          res.status(500).send('Internal Server Error');
          });
    }else{
          res.send({'status' : false, 'message':'Un Authroized'});
    }
          
});

router.get('/:id',(req,res)=>{
    report_perameters.findOne({ where: {id : req.params.id}}).then(exp => {
      if(exp){
          res.send({'status' : true, "message" : exp});
      }else{
          res.send({'status' : false, 'message':'fail'});
      }
  }).catch(err=>{
      res.send({status:false,'message':'Fail'});
  });
});

router.post('/:id',(req,res)=>{
    report_perameters.afterBulkUpdate(function(options) {//hook1
      options.auth = req.auth ? req.auth.userId : 0;
  });
  report_perameters.update({name:req.body.name},{ where: { id: req.params.id }}).then(result=>{
      res.send({'status' : true, "message" : "success"});
  }).catch(err=>{
      console.log(err);
      res.send({'status' : false, 'message':'fail'});
  });
});

module.exports = router;
