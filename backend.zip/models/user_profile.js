/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  let user_profile = sequelize.define('user_profile', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    userId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'users',
        key: 'id'
      }
    },
    about: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    adress: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    pincode: {
      type: DataTypes.STRING(15),
      allowNull: true
    },
    linkedinId: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    resume: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    }
  }, {
    tableName: 'user_profile'
  });
  user_profile.associate = function(models) {
    user_profile.hasMany(models.user_profile_edu,{foreignKey: 'userProfileId'});
    user_profile.hasMany(models.user_profile_exp,{foreignKey: 'userProfileId'});
  };
  return user_profile;
};
