/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('user_profile_exp', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    userProfileId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'user_profile',
        key: 'id'
      }
    },
    organizationName: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    desgination: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    joinedDate: {
      type: DataTypes.DATEONLY,
      allowNull: false
    },
    relivedDate: {
      type: DataTypes.DATEONLY,
      allowNull: true
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    }
  }, {
    tableName: 'user_profile_exp'
  });
};
