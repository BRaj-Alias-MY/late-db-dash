/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('interview_question_template', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    domainId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'domain',
        key: 'id'
      }
    },
    subDomainId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'sub_domains',
        key: 'id'
      }
    },
    name: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    expertLevelId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'exp_level',
        key: 'id'
      }
    },
    duration: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    questionCount: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    organizationId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'interview_type_map',
        key: 'id'
      }
    },
    status: {
      type: DataTypes.ENUM('active','inactive'),
      allowNull: false
    },
    userId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'users',
        key: 'id'
      }
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    }
  }, {
    tableName: 'interview_question_template'
  });
};
