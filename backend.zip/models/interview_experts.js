/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  let interview_experts = sequelize.define('interview_experts', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    interviewUserId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'interview_users',
        key: 'id'
      }
    },
    expertId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'users',
        key: 'id'
      }
    },
    feedback: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    status:{
      type: DataTypes.ENUM('open','inprogress','completed'),
      allowNull: false
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    }
  }, {
    tableName: 'interview_experts'
  });
  interview_experts.associate = function(models) {
    interview_experts.hasMany(models.interview_experts_feedback, {foreignKey: 'interviewExpertId', targetKey: 'id'});
    interview_experts.belongsTo(models.interview_users, {foreignKey: 'interviewUserId', targetKey: 'id'});
  };
  return interview_experts;
};
